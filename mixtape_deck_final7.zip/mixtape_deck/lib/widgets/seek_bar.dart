import 'package:flutter/material.dart';

import '../theme.dart';
import '../utils.dart';

/// Thick orange progress bar with a vertical thumb (like the reference player).
class SeekBar extends StatefulWidget {
  const SeekBar({
    super.key,
    required this.position,
    required this.duration,
    required this.onSeek,
  });

  final Duration position;
  final Duration duration;
  final ValueChanged<Duration> onSeek;

  @override
  State<SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<SeekBar> {
  double? _drag;

  double get _fraction {
    if (_drag != null) return _drag!;
    final total = widget.duration.inMilliseconds;
    if (total <= 0) return 0;
    return (widget.position.inMilliseconds / total).clamp(0.0, 1.0).toDouble();
  }

  double _at(double dx, double width) =>
      width <= 0 ? 0 : (dx / width).clamp(0.0, 1.0).toDouble();

  void _commit(double f) {
    final ms = (widget.duration.inMilliseconds * f).round();
    widget.onSeek(Duration(milliseconds: ms));
  }

  @override
  Widget build(BuildContext context) {
    final shownPos = _drag != null
        ? Duration(milliseconds: (widget.duration.inMilliseconds * _drag!).round())
        : widget.position;

    return Column(
      children: [
        SizedBox(
          height: 44,
          child: LayoutBuilder(
            builder: (context, c) {
              final w = c.maxWidth;
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTapUp: (d) => _commit(_at(d.localPosition.dx, w)),
                onHorizontalDragStart: (d) =>
                    setState(() => _drag = _at(d.localPosition.dx, w)),
                onHorizontalDragUpdate: (d) =>
                    setState(() => _drag = _at(d.localPosition.dx, w)),
                onHorizontalDragEnd: (_) {
                  final f = _drag;
                  setState(() => _drag = null);
                  if (f != null) _commit(f);
                },
                child: CustomPaint(
                  size: Size(w, 44),
                  painter: _BarPainter(_fraction, _drag != null),
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(fmtDuration(shownPos),
                  style: const TextStyle(color: kMuted, fontSize: 13)),
              Text(fmtDuration(widget.duration),
                  style: const TextStyle(color: kMuted, fontSize: 13)),
            ],
          ),
        ),
      ],
    );
  }
}

class _BarPainter extends CustomPainter {
  _BarPainter(this.f, this.dragging);
  final double f;
  final bool dragging;

  @override
  void paint(Canvas canvas, Size s) {
    const h = 8.0;
    final r = dragging ? 11.0 : 9.0; // thumb radius
    final cy = s.height / 2;
    const round = Radius.circular(h / 2);

    // Track.
    canvas.drawRRect(
      RRect.fromLTRBR(0, cy - h / 2, s.width, cy + h / 2, round),
      Paint()..color = const Color(0xFF303030),
    );

    // Orange fill runs right up to the thumb (no gap).
    final tx = r + (s.width - 2 * r) * f;
    canvas.drawRRect(
      RRect.fromLTRBR(0, cy - h / 2, tx, cy + h / 2, round),
      Paint()..color = kOrange,
    );

    // Thumb.
    canvas.drawCircle(
      Offset(tx, cy),
      r + 3,
      Paint()..color = const Color(0x33FF5500),
    );
    canvas.drawCircle(Offset(tx, cy), r, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(_BarPainter old) => old.f != f || old.dragging != dragging;
}

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../player_controller.dart';
import '../screens/now_playing_screen.dart';
import '../theme.dart';
import 'cover_image.dart';
import 'eat_tape.dart';

Future<void> shuffleWholeLibrary(BuildContext context) async {
  final store = context.read<LibraryStore>();
  final pl = context.read<PlayerController>();
  final all = store.allAudio;
  if (all.isEmpty) {
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Eat a tape first')));
    return;
  }
  await pl.playQueue(all, Random().nextInt(all.length), shuffleOn: true);
}

/// Home-screen bottom bar: "Swipe to Shuffle" when idle, the mini-player when
/// something is playing (swipe left = next, right = previous, tap = Now Playing),
/// plus the square "+" Eat Tape button.
class BottomDeck extends StatefulWidget {
  const BottomDeck({super.key});

  @override
  State<BottomDeck> createState() => _BottomDeckState();
}

class _BottomDeckState extends State<BottomDeck> {
  double _dx = 0;

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerController>();
    final r = pl.current;

    final pill = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (r == null) {
          shuffleWholeLibrary(context);
        } else {
          openNowPlaying(context);
        }
      },
      onHorizontalDragUpdate: (d) => setState(() => _dx += d.delta.dx),
      onHorizontalDragEnd: (d) {
        final moved = _dx;
        final v = d.primaryVelocity ?? 0;
        setState(() => _dx = 0);
        final swiped = moved.abs() > 60 || v.abs() > 700;
        if (!swiped) return;
        if (r == null) {
          shuffleWholeLibrary(context);
        } else if (moved < 0 || v < 0) {
          pl.next();
        } else {
          pl.previous();
        }
      },
      child: Container(
        height: 60,
        padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
        decoration: BoxDecoration(
          color: kPill,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Transform.translate(
          offset: Offset(_dx.clamp(-120.0, 120.0).toDouble(), 0),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: SizedBox(
                  width: 44,
                  height: 44,
                  child: CoverImage(path: r?.album.coverPath, cacheWidth: 140),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: r == null
                    ? const Text(
                        'Swipe to Shuffle',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w300),
                      )
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            r.track.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 15, fontWeight: FontWeight.w700),
                          ),
                          Text(
                            r.album.artist,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: kRowMuted, fontSize: 12),
                          ),
                        ],
                      ),
              ),
              if (r != null)
                IconButton(
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(minWidth: 44, minHeight: 44),
                  onPressed: pl.toggle,
                  icon: Icon(
                    pl.playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
                    size: 34,
                    color: kOrange,
                  ),
                ),
            ],
          ),
        ),
      ),
    );

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
        child: Row(
          children: [
            Expanded(child: pill),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => eatTape(context),
              child: Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: kPill,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(Icons.add, size: 28),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Lets non-UI code (the player) show a snackbar.
final GlobalKey<ScaffoldMessengerState> messengerKey =
    GlobalKey<ScaffoldMessengerState>();

const MethodChannel _appChannel = MethodChannel('mixtapezz/app');

/// Sends the app to the background instead of closing it, so music keeps playing.
Future<void> moveAppToBack() async {
  try {
    await _appChannel.invokeMethod<void>('moveToBack');
  } catch (_) {
    await SystemNavigator.pop();
  }
}

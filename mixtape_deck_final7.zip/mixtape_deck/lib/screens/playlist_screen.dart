import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../widgets/menus.dart';
import '../widgets/mini_player.dart';
import '../widgets/playlist_cover.dart';

/// Same page as an album: cover on top, title, PLAY, tracks below.
/// Drag the handle on the right to reorder. Long-press a track for its menu.
class PlaylistScreen extends StatelessWidget {
  const PlaylistScreen({super.key, required this.playlist});

  final Playlist playlist;

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final pl = context.watch<PlayerController>();
    final tracks = store.playlistTracks(playlist);
    final curId = pl.current?.track.id;
    final color = Color(playlist.colorValue);

    return Scaffold(
      appBar: AppBar(
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert),
            onSelected: (v) async {
              if (v == 'edit') {
                await showPlaylistEditor(context, existing: playlist);
              } else if (v == 'delete') {
                final nav = Navigator.of(context);
                await store.deletePlaylist(playlist);
                nav.maybePop();
              }
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'edit', child: Text('Edit playlist')),
              if (!playlist.isFavorites)
                const PopupMenuItem(value: 'delete', child: Text('Delete playlist')),
            ],
          ),
        ],
      ),
      bottomNavigationBar: const SafeArea(top: false, child: MiniPlayer()),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 48),
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: PlaylistCover(playlist: playlist, cacheWidth: 800),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 4),
                  child: Text(playlist.name,
                      style: const TextStyle(
                          fontSize: 24, fontWeight: FontWeight.w900)),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    'Playlist  ·  ${tracks.length} tracks',
                    style: const TextStyle(color: Colors.white54),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: color,
                        foregroundColor: Colors.black,
                      ),
                      onPressed: tracks.isEmpty ? null : () => pl.playQueue(tracks, 0),
                      icon: const Icon(Icons.play_arrow_rounded),
                      label: const Text('PLAY',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ),
                ),
                if (tracks.isEmpty)
                  const Padding(
                    padding: EdgeInsets.fromLTRB(20, 12, 20, 12),
                    child: Text(
                      'Empty for now. Long-press any track and pick "Add to playlist", or tap the heart on the player for Favorites.',
                      style: TextStyle(color: Colors.white54, height: 1.5),
                    ),
                  ),
              ],
            ),
          ),
          SliverReorderableList(
            itemCount: tracks.length,
            onReorder: (o, n) {
              if (n > o) n -= 1;
              store.reorderPlaylist(playlist, o, n);
            },
            itemBuilder: (c, i) {
              final r = tracks[i];
              final active = curId == r.track.id;
              return Material(
                key: ValueKey('${r.track.id}_$i'),
                color: kBlack,
                child: ListTile(
                  onTap: () => pl.playQueue(tracks, i),
                  onLongPress: () =>
                      showTrackMenu(context, r, fromPlaylist: playlist),
                  leading: SizedBox(
                    width: 28,
                    child: Center(
                      child: active
                          ? Icon(pl.playing ? Icons.graphic_eq : Icons.pause,
                              color: color)
                          : Text('${i + 1}',
                              style: const TextStyle(color: Colors.white54)),
                    ),
                  ),
                  title: Text(
                    r.track.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: active ? color : Colors.white,
                    ),
                  ),
                  trailing: ReorderableDragStartListener(
                    index: i,
                    child: const Icon(Icons.drag_handle, color: Colors.white38),
                  ),
                ),
              );
            },
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 24)),
        ],
      ),
    );
  }
}

class Track {
  Track({
    required this.id,
    required this.title,
    required this.path,
    required this.number,
    required this.isVideo,
    this.durationMs,
  });

  final String id;
  String title;
  final String path;
  final int number;
  final bool isVideo;
  int? durationMs;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'path': path,
        'number': number,
        'isVideo': isVideo,
        'durationMs': durationMs,
      };

  factory Track.fromJson(Map<String, dynamic> j) => Track(
        id: j['id'] as String,
        title: j['title'] as String,
        path: j['path'] as String,
        number: (j['number'] as num?)?.toInt() ?? 0,
        isVideo: j['isVideo'] as bool? ?? false,
        durationMs: (j['durationMs'] as num?)?.toInt(),
      );
}

class Album {
  Album({
    required this.id,
    required this.title,
    required this.artist,
    required this.dirPath,
    required this.tracks,
    this.coverPath,
    this.pinned = false,
    this.hidden = false,
    int? addedAt,
  }) : addedAt = addedAt ?? DateTime.now().millisecondsSinceEpoch;

  final String id;
  String title;
  String artist;
  final String dirPath;
  String? coverPath;
  bool pinned;

  /// Standalone imported videos live in a hidden "album": they show in the
  /// Videos tab but not in the Tapes list.
  bool hidden;
  final int addedAt;
  final List<Track> tracks;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'artist': artist,
        'dirPath': dirPath,
        'coverPath': coverPath,
        'pinned': pinned,
        'hidden': hidden,
        'addedAt': addedAt,
        'tracks': tracks.map((t) => t.toJson()).toList(),
      };

  factory Album.fromJson(Map<String, dynamic> j) => Album(
        id: j['id'] as String,
        title: j['title'] as String,
        artist: j['artist'] as String,
        dirPath: j['dirPath'] as String,
        coverPath: j['coverPath'] as String?,
        pinned: j['pinned'] as bool? ?? false,
        hidden: j['hidden'] as bool? ?? false,
        addedAt: (j['addedAt'] as num?)?.toInt(),
        tracks: (j['tracks'] as List)
            .map((t) => Track.fromJson(Map<String, dynamic>.from(t as Map)))
            .toList(),
      );
}

/// A track together with the album it lives in.
class TrackRef {
  const TrackRef(this.track, this.album);
  final Track track;
  final Album album;
}

class Playlist {
  Playlist({
    required this.id,
    required this.name,
    required this.colorValue,
    this.coverPath,
    List<String>? trackIds,
  }) : trackIds = trackIds ?? [];

  final String id;
  String name;
  int colorValue;
  String? coverPath;
  final List<String> trackIds;

  bool get isFavorites => id == 'favorites';

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'colorValue': colorValue,
        'coverPath': coverPath,
        'trackIds': trackIds,
      };

  factory Playlist.fromJson(Map<String, dynamic> j) => Playlist(
        id: j['id'] as String,
        name: j['name'] as String,
        colorValue: (j['colorValue'] as num).toInt(),
        coverPath: j['coverPath'] as String?,
        trackIds: (j['trackIds'] as List?)?.map((e) => e as String).toList(),
      );
}

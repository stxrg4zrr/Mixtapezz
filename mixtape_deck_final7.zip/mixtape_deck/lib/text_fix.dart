import 'dart:convert';

/// Repairs tag text that was decoded the wrong way:
///  - UTF-16 little-endian text read as big-endian (shows as boxes / CJK gibberish)
///  - UTF-8 text read as Latin-1 (shows as "Ã©" style junk)
///  - stray NUL / BOM characters
String fixTagText(String input) {
  var s = input;
  if (s.isEmpty) return s;

  final u = s.codeUnits;
  var zeroLow = 0;
  for (final c in u) {
    if ((c & 0xFF) == 0) zeroLow++;
  }
  final leBom = u.first == 0xFFFE; // FF FE read as big-endian
  if (leBom || (u.length >= 2 && zeroLow >= u.length * 0.6)) {
    final units = <int>[];
    for (var i = leBom ? 1 : 0; i < u.length; i++) {
      final c = u[i];
      units.add(((c & 0xFF) << 8) | (c >> 8));
    }
    s = String.fromCharCodes(units);
  }

  s = s.replaceAll('\uFFFE', '').replaceAll('\uFEFF', '');
  // stray control characters (shown as empty boxes)
  s = s.replaceAll(RegExp('[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]'), '');

  if (s.codeUnits.every((c) => c < 256) &&
      RegExp('[\u00C2-\u00F4][\u0080-\u00BF]').hasMatch(s)) {
    try {
      final fixed = utf8.decode(latin1.encode(s));
      if (fixed.isNotEmpty) s = fixed;
    } catch (_) {}
  }
  return s.trim();
}
